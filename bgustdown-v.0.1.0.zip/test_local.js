const { Bgustdown } = require('./index.js');

async function runStressTest() {
  const client = new Bgustdown();
  
  const files = [
    { name: 'Excel (Diseño Instruccional)', path: '/home/august/Downloads/DiseñoInstruccional_Cursos.xlsx' },
    { name: 'Word (Capítulo 3)', path: '/home/august/Downloads/cap3-sin-corregir.docx' }
  ];
  
  console.log(`\n🔥 Iniciando Prueba de Estrés Simultánea (Promesas Paralelas)`);
  
  const startTime = Date.now();

  try {
    // Ejecutamos ambas conversiones en paralelo para probar la concurrencia de Rust/Tokio
    const results = await Promise.all(files.map(async (file) => {
      const fileStart = Date.now();
      const markdown = await client.convert(file.path);
      const sentences = client.prepareTrainingData(markdown, file.name, 'general');
      const fileEnd = Date.now();
      
      return {
        name: file.name,
        time: fileEnd - fileStart,
        chars: markdown.length,
        sentences: sentences.length,
        preview: markdown.substring(0, 300)
      };
    }));

    const totalTime = Date.now() - startTime;

    results.forEach(res => {
      console.log(`\n--- [RESULTADO: ${res.name}] ---`);
      console.log(`⏱️ Tiempo individual: ${res.time}ms`);
      console.log(`📊 Estadísticas: ${res.chars} caracteres, ${res.sentences} oraciones.`);
      console.log(`📝 Vista previa:\n${res.preview}...`);
    });

    console.log(`\n✅ PRUEBA DE ESTRÉS COMPLETADA`);
    console.log(`🚀 Tiempo total de ejecución (Paralelo): ${totalTime}ms`);

  } catch (error) {
    console.error('❌ Error durante la prueba de estrés:', error);
  }
}

runStressTest();
