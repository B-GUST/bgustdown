# bgustdown 🚀

**El motor de conversión de documentos definitivo para la era de la IA.**

**bgustdown** es una librería de altísimo rendimiento escrita en Rust, diseñada para extraer, limpiar y segmentar contenido de diversos formatos de documentos. Convierte PDFs, documentos de Word y hojas de cálculo masivas en Markdown estructurado y datasets listos para el entrenamiento de modelos de lenguaje (NLP), procesando en paralelo y en milisegundos.

## ¿Qué problema resuelve?
Procesar documentos empresariales o académicos (PDFs, Excel, Word) para alimentar sistemas de IA (RAG) o entrenar modelos (Fine-tuning) es tradicionalmente un proceso lento, bloqueante y propenso a errores de formato. 

**bgustdown** elimina el cuello de botella:
- **Velocidad Rust:** Procesamiento concurrente sin el GIL de Python. Un Excel masivo o un capítulo de Word se procesan en ~15ms.
- **Data Engineering Nativo:** Integra **Apache Arrow** para el manejo en memoria de datos tabulares (CSV, XLSX), garantizando eficiencia extrema.
- **Inteligencia Estructural:** No solo lee el texto; limpia semánticamente el ruido (números de página, cabeceras repetidas) y segmenta inteligentemente las oraciones respetando el contexto bidireccional (ideal para BERT/BETO).

## Características y Alcance

- **Formatos de Texto:** `.docx`, `.odt` (Extracción precisa de jerarquías y tablas nativas).
- **Formatos Tabulares:** `.xlsx`, `.xls`, `.xlsb`, `.ods`, `.csv` (Procesamiento masivo vía Arrow).
- **Formatos Rígidos:** `.pdf` (Extracción de texto digital rápido).
- **Preparación de Datasets:** Exportación a JSONL y segmentación de oraciones (NSP - Next Sentence Prediction) lista para Machine Learning.
- **Zero Python Dependency:** Binarios nativos precompilados vía NAPI-RS. Solo haz `npm install` y listo.

## Instalación

```bash
npm install bgustdown
```

## Guía Rápida de Uso

### 1. Conversión Rápida a Markdown Limpio

```javascript
const { Bgustdown } = require('bgustdown');

async function convertDocument() {
  const client = new Bgustdown();
  
  // Soporta PDF, DOCX, ODT, XLSX, ODS, CSV...
  const markdown = await client.convert('./reporte_financiero.xlsx');
  
  console.log(markdown);
}

convertDocument();
```

### 2. Preparación de Datasets para NLP (Fine-Tuning)

Si necesitas entrenar modelos, bgustdown limpia y segmenta el texto en oraciones con contexto preservado:

```javascript
const { Bgustdown } = require('bgustdown');

async function prepareDataset() {
  const client = new Bgustdown();
  const markdown = await client.convert('./ley_general.pdf');
  
  // Limpia el ruido y segmenta inteligentemente
  const sentences = client.prepareTrainingData(markdown, 'documento_legal', 'derecho');
  
  console.log(`Oraciones extraídas: ${sentences.length}`);
  console.log(sentences.slice(0, 3));
}

prepareDataset();
```

## Atribución y Licencia

Este proyecto ha sido desarrollado con inspiración y basándose en el diseño conceptual del proyecto **MarkItDown** de Microsoft Corporation.

- **Proyecto Original:** [MarkItDown](https://github.com/microsoft/markitdown)
- **Autor Original:** Microsoft Corporation
- **Licencia Original:** MIT

**Cambios y Mejoras en bgustdown:**
Hemos portado la filosofía a **Rust**, integrado Apache Arrow, añadido capacidades de segmentación semántica para NLP y construido bindings nativos para Node.js usando `napi-rs` para un rendimiento inigualable.

**Licencia de bgustdown:** MIT
